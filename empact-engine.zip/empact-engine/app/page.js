"use client";
import React, { useState, useRef, useEffect } from "react";

const C = {
  purple: "#945EFF",
  blue: "#4A5BF0",
  navy: "#114596",
  teal: "#A1D4D2",
  ink: "#0C202C",
  grey: "#E9E9EE",
};

const AGENTS = [
  {
    id: "scout", n: 1, icon: "🤖", name: "Scout", title: "Finds & scores CPO leads",
    sys: `You are Scout, lead-gen agent for Electric Miles' emPACT product (a hardware-agnostic Charge Point Management System / CPMS for fleet depots and CPOs). Founder: Arun Anand.

Find real, named prospects that fit emPACT: UK and EU charge point operators, depot fleet operators, bus operators, leasing/installer channels. For each, return a tight profile and a fit SCORE out of 100.

Scoring weights: charger estate size / depot footprint (30), hardware-agnostic need i.e. mixed OCPP hardware (20), grid-flex / SmartFlex upside (20), DCS Window 1 eligibility if UK and deadline 30 June 2026 (15), buying readiness / EV mandate pressure (15).

Output as STRICT JSON only, no prose, no markdown fences:
{"leads":[{"company":"","domain":"","segment":"","why_fit":"","est_chargers":"","score":0,"signals":["",""]}]}
Return 5 to 8 leads. Keep why_fit under 20 words. No em-dashes anywhere.`,
  },
  {
    id: "analyst", n: 2, icon: "🕵️", name: "Analyst", title: "Qualifies & finds the buyer",
    sys: `You are Analyst, qualification agent for emPACT (Electric Miles CPMS, hardware-agnostic, fleet depot + CPO focus).

Given a target company, research them and decide if they are a genuine emPACT fit. Confirm: charger estate, hardware vendors in use, grid constraints, DCS eligibility (UK, window closes 30 June 2026). Identify the decision maker (role + name if findable) and a likely email pattern from the domain.

Output STRICT JSON only, no prose, no fences:
{"verdict":"strong fit | possible fit | poor fit","reasoning":"","decision_maker":{"name":"","role":"","email_guess":""},"qualifying_questions":["","",""],"emPACT_angle":""}
Keep reasoning under 40 words. emPACT_angle ties to one product: emPACT CPMS, SmartFlex flex revenue, or DCS grant support. No em-dashes.`,
  },
  {
    id: "writer", n: 3, icon: "✍️", name: "Closer-Prep", title: "Writes outreach + sequence",
    sys: `You are the outreach writer for emPACT (Electric Miles CPMS). Voice: Arun Anand, CEO. Direct, outcome-first, no corporate filler, no hedging, no em-dashes. Concise and punchy.

emPACT facts you may use: hardware-agnostic CPMS; 20,000+ chargers connected; 97.9 to 99.5% uptime; SmartFlex grid-flexibility revenue (V1G smart charging); accredited DCS delivery partner (£170M UK scheme, Window 1 closes 30 June 2026, 70% grant); asset-light software layer above any OCPP hardware.

Given a qualified prospect, produce STRICT JSON only, no prose, no fences:
{"cold_email":{"subject":"","body":""},"sequence":[{"step":1,"timing":"","angle":"","message":""}],"call_script":{"opener":"","value":"","objection_pivot":"","close":""}}
Cold email body under 110 words. Build exactly 5 sequence steps. No em-dashes anywhere.`,
  },
  {
    id: "coach", n: 4, icon: "🏆", name: "Coach", title: "Preps you to close",
    sys: `You are Coach, deal-prep agent for emPACT (Electric Miles CPMS). Prepare the rep to win the meeting.

Cover emPACT-specific objections: "we already have a CPMS", "hardware lock-in concerns", "why not go direct to the charger vendor", "what is SmartFlex worth", "can you hit the DCS 30 June 2026 deadline", "asset-light means you do not own the risk". Use real positioning: hardware-agnostic moat, SmartFlex flex revenue share, DCS 70% grant support, proven uptime.

Output STRICT JSON only, no prose, no fences:
{"tactics":["","",""],"objections":[{"objection":"","response":""}],"closes":[{"name":"","script":""}]}
Provide 4 tactics, 5 objections, exactly 4 closes (e.g. assumptive, pilot-first, deadline, ROI). Keep each response under 45 words. No em-dashes.`,
  },
];

async function callClaude(system, user, useSearch) {
  let res;
  try {
    res = await fetch("/api/agent", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ system, user, useSearch }),
    });
  } catch (e) {
    throw new Error("Could not reach the server. Is the app running? " + e.message);
  }

  const data = await res.json();
  if (!res.ok) throw new Error(data.error || ("Server error " + res.status));

  const text = (data.text || "").trim();
  if (!text) throw new Error("Empty response. Try again, or turn off web search.");

  const clean = text.replace(/```json|```/g, "").trim();
  const s = clean.indexOf("{");
  const e = clean.lastIndexOf("}");
  if (s === -1 || e === -1) throw new Error("Model did not return JSON. Raw: " + clean.slice(0, 160));
  try {
    return JSON.parse(clean.slice(s, e + 1));
  } catch {
    throw new Error("Could not parse JSON. Raw: " + clean.slice(0, 160));
  }
}

function Pill({ children, bg, fg }) {
  return (
    <span style={{ background: bg, color: fg || "#fff", fontSize: 11, fontWeight: 700, padding: "3px 9px", borderRadius: 20, letterSpacing: 0.3, whiteSpace: "nowrap" }}>
      {children}
    </span>
  );
}

function ScoreRing({ score }) {
  const col = score >= 80 ? C.purple : score >= 60 ? C.blue : C.navy;
  return (
    <div style={{ position: "relative", width: 52, height: 52, flexShrink: 0 }}>
      <svg width="52" height="52" style={{ transform: "rotate(-90deg)" }}>
        <circle cx="26" cy="26" r="22" fill="none" stroke={C.grey} strokeWidth="5" />
        <circle cx="26" cy="26" r="22" fill="none" stroke={col} strokeWidth="5" strokeLinecap="round" strokeDasharray={`${(score / 100) * 138} 138`} />
      </svg>
      <div style={{ position: "absolute", inset: 0, display: "grid", placeItems: "center", fontWeight: 800, fontSize: 15, color: C.ink }}>{score}</div>
    </div>
  );
}

export default function Page() {
  const [stage, setStage] = useState(0);
  const [running, setRunning] = useState(false);
  const [useSearch, setUseSearch] = useState(false);
  const [err, setErr] = useState("");
  const [seedMode, setSeedMode] = useState("auto");
  const [manualSeed, setManualSeed] = useState("");
  const [leads, setLeads] = useState([]);
  const [selected, setSelected] = useState(null);
  const [qual, setQual] = useState(null);
  const [outreach, setOutreach] = useState(null);
  const [coaching, setCoaching] = useState(null);
  const log = useRef(null);

  useEffect(() => { if (log.current) log.current.scrollTop = log.current.scrollHeight; }, [leads, qual, outreach, coaching]);

  async function runScout() {
    setRunning(true); setErr("");
    try {
      const u = seedMode === "auto"
        ? "Find emPACT CPO/depot prospects in the UK and EU now. Prioritise DCS Window 1 eligible UK fleet operators."
        : `Score and profile these candidate prospects for emPACT fit:\n${manualSeed}`;
      const r = await callClaude(AGENTS[0].sys, u, useSearch && seedMode === "auto");
      setLeads((r.leads || []).sort((a, b) => b.score - a.score)); setStage(1);
    } catch (e) { setErr("Scout failed: " + e.message); }
    setRunning(false);
  }

  async function runAnalyst(lead) {
    setSelected(lead); setRunning(true); setErr(""); setQual(null); setOutreach(null); setCoaching(null);
    try {
      const u = `Qualify this emPACT prospect:\nCompany: ${lead.company}\nDomain: ${lead.domain}\nSegment: ${lead.segment}\nWhy flagged: ${lead.why_fit}\nEstimated chargers: ${lead.est_chargers}`;
      const r = await callClaude(AGENTS[1].sys, u, useSearch);
      setQual(r); setStage(2);
    } catch (e) { setErr("Analyst failed: " + e.message); }
    setRunning(false);
  }

  async function runWriter() {
    setRunning(true); setErr("");
    try {
      const u = `Write outreach for:\nCompany: ${selected.company}\nDecision maker: ${qual.decision_maker.name} (${qual.decision_maker.role})\nemPACT angle: ${qual.emPACT_angle}\nVerdict: ${qual.verdict}`;
      const r = await callClaude(AGENTS[2].sys, u, false);
      setOutreach(r); setStage(3);
    } catch (e) { setErr("Closer-Prep failed: " + e.message); }
    setRunning(false);
  }

  async function runCoach() {
    setRunning(true); setErr("");
    try {
      const u = `Prep me to close ${selected.company}. Angle: ${qual.emPACT_angle}. Decision maker: ${qual.decision_maker.role}.`;
      const r = await callClaude(AGENTS[3].sys, u, false);
      setCoaching(r);
    } catch (e) { setErr("Coach failed: " + e.message); }
    setRunning(false);
  }

  function reset() {
    setStage(0); setLeads([]); setSelected(null); setQual(null); setOutreach(null); setCoaching(null); setErr("");
  }

  const cardBg = "#FBFBFD";
  const mono = "'Courier New', monospace";

  return (
    <div style={{ minHeight: "100vh", background: `radial-gradient(1200px 600px at 80% -10%, rgba(148,94,255,.18), transparent), radial-gradient(900px 500px at -10% 110%, rgba(74,91,240,.16), transparent), ${C.ink}`, fontFamily: "Montserrat, system-ui, sans-serif", color: C.ink, padding: "0 0 60px" }}>
      <style>{`*{box-sizing:border-box} button{font-family:inherit;cursor:pointer}
        .glow{box-shadow:0 0 0 1px rgba(255,255,255,.06),0 18px 50px rgba(0,0,0,.35)}
        @keyframes pulse{0%,100%{opacity:.4}50%{opacity:1}} .dot{animation:pulse 1.1s infinite}
        textarea,input{font-family:inherit}`}</style>

      <div style={{ maxWidth: 1080, margin: "0 auto", padding: "34px 22px 8px", display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 10, height: 30, background: C.purple, borderRadius: 3 }} />
            <h1 style={{ margin: 0, color: "#fff", fontWeight: 900, fontSize: 30, letterSpacing: -0.5 }}>emPACT Sales Engine</h1>
          </div>
          <p style={{ margin: "8px 0 0 20px", color: C.teal, fontWeight: 600, fontSize: 13.5, letterSpacing: 0.5 }}>
            FOUR AGENTS · ONE COMMAND · YOU SHOW UP AND CLOSE
          </p>
        </div>
        <div style={{ textAlign: "right", color: "rgba(255,255,255,.55)", fontSize: 11, fontWeight: 700, letterSpacing: 1 }}>
          ELECTRIC MILES<br />CPO PRODUCT
        </div>
      </div>

      <div style={{ maxWidth: 1080, margin: "18px auto 0", padding: "0 22px", display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 12 }}>
        {AGENTS.map((a, i) => {
          const done = i < stage, active = i === stage;
          return (
            <div key={a.id} className="glow" style={{ background: active ? "#fff" : "rgba(255,255,255,.06)", borderRadius: 14, padding: "14px 14px 16px", border: active ? `2px solid ${C.purple}` : "2px solid transparent", transition: "all .3s" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <span style={{ fontSize: 22 }}>{a.icon}</span>
                {done ? <Pill bg={C.teal} fg={C.ink}>DONE</Pill> : active ? <Pill bg={C.purple}>ACTIVE</Pill> : <span style={{ color: "rgba(255,255,255,.35)", fontSize: 11, fontWeight: 700 }}>0{a.n}</span>}
              </div>
              <div style={{ marginTop: 10, fontWeight: 800, fontSize: 15, color: active ? C.ink : "#fff" }}>{a.name}</div>
              <div style={{ fontSize: 11.5, fontWeight: 600, color: active ? C.navy : "rgba(255,255,255,.55)", marginTop: 2 }}>{a.title}</div>
            </div>
          );
        })}
      </div>

      <div ref={log} style={{ maxWidth: 1080, margin: "22px auto 0", padding: "0 22px" }}>
        <div className="glow" style={{ background: "#fff", borderRadius: 18, padding: "22px 22px 24px", minHeight: 360 }}>

          {stage === 0 && (
            <div>
              <Head icon="🤖" name="Scout" sub="Find and score emPACT CPO prospects" />
              <div style={{ display: "flex", gap: 8, margin: "16px 0" }}>
                {[["auto", "Live prospecting"], ["manual", "Paste my leads"]].map(([k, lbl]) => (
                  <button key={k} onClick={() => setSeedMode(k)} style={{ flex: 1, padding: "11px", borderRadius: 10, border: seedMode === k ? `2px solid ${C.purple}` : `2px solid ${C.grey}`, background: seedMode === k ? "rgba(148,94,255,.08)" : "#fff", fontWeight: 700, fontSize: 13, color: C.ink }}>{lbl}</button>
                ))}
              </div>
              {seedMode === "manual" ? (
                <textarea value={manualSeed} onChange={(e) => setManualSeed(e.target.value)} placeholder={"One prospect per line, e.g.\nMer (mer.eco) — UK public charging CPO\nGRIDSERVE — fleet + forecourt operator"} style={{ width: "100%", minHeight: 110, padding: 12, borderRadius: 10, border: `2px solid ${C.grey}`, fontFamily: mono, fontSize: 13, resize: "vertical" }} />
              ) : (
                <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "12px 14px", background: C.grey, borderRadius: 10, fontSize: 13, fontWeight: 600, color: C.navy }}>
                  <input type="checkbox" checked={useSearch} onChange={(e) => setUseSearch(e.target.checked)} />
                  Use live web search (optional, slower; turn off if Scout fails)
                </div>
              )}
              <RunBtn onClick={runScout} running={running} disabled={seedMode === "manual" && !manualSeed.trim()} label="Run Scout" />
            </div>
          )}

          {stage >= 1 && leads.length > 0 && (
            <Section open={stage === 1} icon="🤖" name="Scout" sub={`${leads.length} scored prospects`}>
              <div style={{ display: "grid", gap: 10, marginTop: 4 }}>
                {leads.map((l, i) => (
                  <div key={i} style={{ display: "flex", gap: 14, alignItems: "center", padding: "13px 15px", background: cardBg, borderRadius: 12, border: selected?.company === l.company ? `2px solid ${C.purple}` : `1px solid ${C.grey}` }}>
                    <ScoreRing score={l.score} />
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontWeight: 800, fontSize: 15 }}>{l.company} <span style={{ color: C.blue, fontWeight: 600, fontSize: 12 }}>{l.domain}</span></div>
                      <div style={{ fontSize: 12.5, color: "#445", marginTop: 2 }}>{l.why_fit}</div>
                      <div style={{ display: "flex", gap: 6, marginTop: 7, flexWrap: "wrap" }}>
                        <Pill bg={C.navy}>{l.segment}</Pill>
                        {l.est_chargers && <Pill bg={C.grey} fg={C.ink}>{l.est_chargers} chargers</Pill>}
                        {(l.signals || []).slice(0, 2).map((s, j) => <Pill key={j} bg="rgba(74,91,240,.12)" fg={C.navy}>{s}</Pill>)}
                      </div>
                    </div>
                    <button onClick={() => runAnalyst(l)} disabled={running} style={{ padding: "9px 14px", borderRadius: 9, border: "none", background: C.purple, color: "#fff", fontWeight: 700, fontSize: 12.5, whiteSpace: "nowrap" }}>Qualify →</button>
                  </div>
                ))}
              </div>
            </Section>
          )}

          {qual && (
            <Section open={stage === 2} icon="🕵️" name="Analyst" sub={`${selected.company} · qualification`}>
              <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
                <Pill bg={qual.verdict?.includes("strong") ? C.purple : qual.verdict?.includes("poor") ? "#b04a4a" : C.blue}>{(qual.verdict || "").toUpperCase()}</Pill>
              </div>
              <p style={{ margin: "0 0 14px", fontSize: 13.5, lineHeight: 1.5, color: "#334" }}>{qual.reasoning}</p>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                <Box title="Decision maker">
                  <div style={{ fontWeight: 800 }}>{qual.decision_maker?.name || "TBD"}</div>
                  <div style={{ fontSize: 12.5, color: C.navy }}>{qual.decision_maker?.role}</div>
                  <div style={{ fontFamily: mono, fontSize: 12, marginTop: 6, color: C.blue }}>{qual.decision_maker?.email_guess}</div>
                </Box>
                <Box title="emPACT angle"><div style={{ fontSize: 13, lineHeight: 1.45 }}>{qual.emPACT_angle}</div></Box>
              </div>
              <Box title="Qualifying questions" mt>
                <ol style={{ margin: 0, paddingLeft: 18, fontSize: 13, lineHeight: 1.6 }}>
                  {(qual.qualifying_questions || []).map((q, i) => <li key={i}>{q}</li>)}
                </ol>
              </Box>
              {stage === 2 && <RunBtn onClick={runWriter} running={running} label="Write outreach →" />}
            </Section>
          )}

          {outreach && (
            <Section open={stage === 3 && !coaching} icon="✍️" name="Closer-Prep" sub="Cold email, sequence, call script">
              <Box title="Cold email">
                <Copyable text={`Subject: ${outreach.cold_email.subject}\n\n${outreach.cold_email.body}`}>
                  <div style={{ fontWeight: 800, fontSize: 13.5, marginBottom: 6 }}>Subject: {outreach.cold_email.subject}</div>
                  <div style={{ fontSize: 13, lineHeight: 1.55, whiteSpace: "pre-wrap" }}>{outreach.cold_email.body}</div>
                </Copyable>
              </Box>
              <Box title="5-step follow-up sequence" mt>
                <div style={{ display: "grid", gap: 8 }}>
                  {(outreach.sequence || []).map((s) => (
                    <div key={s.step} style={{ display: "flex", gap: 10 }}>
                      <div style={{ width: 26, height: 26, flexShrink: 0, background: C.purple, color: "#fff", borderRadius: 8, display: "grid", placeItems: "center", fontWeight: 800, fontSize: 12 }}>{s.step}</div>
                      <div style={{ fontSize: 12.5 }}>
                        <span style={{ fontWeight: 700, color: C.navy }}>{s.timing} · {s.angle}</span><br />
                        <span style={{ color: "#445" }}>{s.message}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </Box>
              <Box title="Call script" mt>
                {["opener", "value", "objection_pivot", "close"].map((k) => (
                  <div key={k} style={{ marginBottom: 8, fontSize: 13 }}>
                    <span style={{ fontWeight: 700, color: C.blue, textTransform: "capitalize" }}>{k.replace("_", " ")}: </span>
                    {outreach.call_script?.[k]}
                  </div>
                ))}
              </Box>
              {!coaching && <RunBtn onClick={runCoach} running={running} label="Prep me to close →" />}
            </Section>
          )}

          {coaching && (
            <Section open icon="🏆" name="Coach" sub="Meeting prep">
              <Box title="Tactics">
                <ul style={{ margin: 0, paddingLeft: 18, fontSize: 13, lineHeight: 1.6 }}>
                  {(coaching.tactics || []).map((t, i) => <li key={i}>{t}</li>)}
                </ul>
              </Box>
              <Box title="Objection responses" mt>
                <div style={{ display: "grid", gap: 9 }}>
                  {(coaching.objections || []).map((o, i) => (
                    <div key={i} style={{ fontSize: 12.5 }}>
                      <div style={{ fontWeight: 700, color: "#b04a4a" }}>“{o.objection}”</div>
                      <div style={{ color: "#334", marginTop: 2 }}>{o.response}</div>
                    </div>
                  ))}
                </div>
              </Box>
              <Box title="Closing scripts" mt>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                  {(coaching.closes || []).map((c, i) => (
                    <div key={i} style={{ background: "rgba(148,94,255,.07)", borderRadius: 10, padding: 12 }}>
                      <Pill bg={C.purple}>{c.name}</Pill>
                      <div style={{ fontSize: 12.5, marginTop: 7, lineHeight: 1.45 }}>{c.script}</div>
                    </div>
                  ))}
                </div>
              </Box>
              <div style={{ marginTop: 18, padding: "14px 16px", background: C.ink, borderRadius: 12, color: "#fff", textAlign: "center" }}>
                <div style={{ fontWeight: 800, fontSize: 15 }}>You type one command. All 4 run.</div>
                <div style={{ color: C.teal, fontSize: 13, fontWeight: 600, marginTop: 2 }}>You just show up and close.</div>
                <button onClick={reset} style={{ marginTop: 12, padding: "9px 20px", borderRadius: 9, border: `1px solid ${C.purple}`, background: "transparent", color: "#fff", fontWeight: 700, fontSize: 13 }}>Run a new prospect</button>
              </div>
            </Section>
          )}

          {err && <div style={{ marginTop: 14, padding: 12, background: "#fdecec", color: "#b04a4a", borderRadius: 10, fontSize: 13, fontWeight: 600 }}>{err}</div>}
          {running && <div style={{ marginTop: 14, display: "flex", alignItems: "center", gap: 8, color: C.navy, fontWeight: 700, fontSize: 13 }}><span className="dot">●</span> Agent working...</div>}
        </div>
      </div>
    </div>
  );
}

function Head({ icon, name, sub }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 11 }}>
      <span style={{ fontSize: 24 }}>{icon}</span>
      <div><div style={{ fontWeight: 900, fontSize: 18 }}>{name}</div><div style={{ fontSize: 12.5, color: "#667", fontWeight: 600 }}>{sub}</div></div>
    </div>
  );
}

function Section({ icon, name, sub, children, open }) {
  const [show, setShow] = useState(open);
  useEffect(() => setShow(open), [open]);
  return (
    <div style={{ borderTop: `1px solid #eceef4`, paddingTop: 16, marginTop: 16 }}>
      <div onClick={() => setShow((s) => !s)} style={{ cursor: "pointer", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <Head icon={icon} name={name} sub={sub} />
        <span style={{ color: "#aab", fontSize: 13 }}>{show ? "▾" : "▸"}</span>
      </div>
      {show && <div style={{ marginTop: 14 }}>{children}</div>}
    </div>
  );
}

function Box({ title, children, mt }) {
  return (
    <div style={{ marginTop: mt ? 12 : 0 }}>
      <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: 1, color: "#889", textTransform: "uppercase", marginBottom: 6 }}>{title}</div>
      <div style={{ background: "#FBFBFD", border: "1px solid #eceef4", borderRadius: 11, padding: 14 }}>{children}</div>
    </div>
  );
}

function Copyable({ text, children }) {
  const [c, setC] = useState(false);
  return (
    <div style={{ position: "relative" }}>
      {children}
      <button onClick={() => { navigator.clipboard?.writeText(text); setC(true); setTimeout(() => setC(false), 1400); }} style={{ position: "absolute", top: -4, right: -4, padding: "4px 10px", borderRadius: 7, border: "none", background: c ? C.teal : C.grey, color: C.ink, fontWeight: 700, fontSize: 11 }}>{c ? "Copied" : "Copy"}</button>
    </div>
  );
}

function RunBtn({ onClick, running, disabled, label }) {
  return (
    <button onClick={onClick} disabled={running || disabled} style={{ marginTop: 18, width: "100%", padding: "14px", borderRadius: 11, border: "none", background: running || disabled ? "#c9c9d6" : `linear-gradient(90deg, ${C.purple}, ${C.blue})`, color: "#fff", fontWeight: 800, fontSize: 14.5, letterSpacing: 0.3 }}>
      {running ? "Working..." : label}
    </button>
  );
}
